# EECE7398-project

Run sim_full_dynamics.m to simulate the 3 link biped in the sagittal plane
